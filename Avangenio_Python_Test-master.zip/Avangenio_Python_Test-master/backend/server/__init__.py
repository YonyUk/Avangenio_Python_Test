'''
server

the implementation for the server
'''
from .server import Server